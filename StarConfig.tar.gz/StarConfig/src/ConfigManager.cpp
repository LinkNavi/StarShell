#include "ConfigManager.h"
#include <QFile>
#include <QDir>
#include <QStandardPaths>
#include <QDebug>

ConfigManager::ConfigManager(QObject *parent) : QObject(parent) {
    // Connect to compositor IPC
    m_ipc = starview_ipc_connect();
    if (!m_ipc) {
        qWarning() << "Failed to connect to StarView IPC";
    }
    
    // Load config
    loadFromFile();
    
    // Watch for external changes
    m_watcher = new QFileSystemWatcher(this);
    m_watcher->addPath(configPath());
    
    connect(m_watcher, &QFileSystemWatcher::fileChanged, this, [this]() {
        qDebug() << "Config file changed externally, reloading...";
        loadFromFile();
        
        // Re-add watch
        if (!m_watcher->files().contains(configPath())) {
            m_watcher->addPath(configPath());
        }
    });
}

ConfigManager::~ConfigManager() {
    if (m_ipc) {
        starview_ipc_disconnect(m_ipc);
    }
}

QString ConfigManager::configPath() const {
    return QDir::homePath() + "/.config/starview/config.toml";
}

void ConfigManager::loadFromFile() {
    QString path = configPath();
    
    FILE *fp = fopen(path.toUtf8().constData(), "r");
    if (!fp) {
        qWarning() << "Failed to open config file:" << path;
        return;
    }
    
    char errbuf[256];
    toml_table_t *root = toml_parse_file(fp, errbuf, sizeof(errbuf));
    fclose(fp);
    
    if (!root) {
        qWarning() << "Failed to parse config:" << errbuf;
        return;
    }
    
    // Parse [general] section
    toml_table_t *general = toml_table_in(root, "general");
    if (general) {
        toml_datum_t val;
        
        val = toml_int_in(general, "gap_size");
        if (val.ok) m_gapSize = val.u.i;
        
        val = toml_int_in(general, "border_width");
        if (val.ok) m_borderWidth = val.u.i;
        
        val = toml_string_in(general, "border_color");
        if (val.ok) {
            m_borderColor = QString(val.u.s);
            free(val.u.s);
        }
        
        val = toml_string_in(general, "focused_border_color");
        if (val.ok) {
            m_focusedBorderColor = QString(val.u.s);
            free(val.u.s);
        }
    }
    
    // Parse [decoration] section
    toml_table_t *decoration = toml_table_in(root, "decoration");
    if (decoration) {
        toml_datum_t val;
        
        val = toml_bool_in(decoration, "enabled");
        if (val.ok) m_decorationsEnabled = val.u.b;
        
        val = toml_int_in(decoration, "titlebar_height");
        if (val.ok) m_titlebarHeight = val.u.i;
        
        val = toml_string_in(decoration, "bg_color");
        if (val.ok) {
            m_decorationBgColor = QString(val.u.s);
            free(val.u.s);
        }
        
        val = toml_string_in(decoration, "text_color");
        if (val.ok) {
            m_decorationTextColor = QString(val.u.s);
            free(val.u.s);
        }
    }
    
    // Parse [wallpaper] section
    toml_table_t *wallpaper = toml_table_in(root, "wallpaper");
    if (wallpaper) {
        toml_datum_t val;
        
        val = toml_string_in(wallpaper, "path");
        if (val.ok) {
            m_wallpaperPath = QString(val.u.s);
            free(val.u.s);
        }
        
        val = toml_string_in(wallpaper, "mode");
        if (val.ok) {
            m_wallpaperMode = QString(val.u.s);
            free(val.u.s);
        }
    }
    
    toml_free(root);
    emit configChanged();
    
    qDebug() << "Config loaded successfully";
}

void ConfigManager::saveToFile() {
    QString path = configPath();
    
    // Ensure config directory exists
    QDir dir = QFileInfo(path).dir();
    if (!dir.exists()) {
        dir.mkpath(".");
    }
    
    QFile file(path);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qWarning() << "Failed to open config file for writing:" << path;
        return;
    }
    
    QTextStream out(&file);
    
    // Write [general]
    out << "[general]\n";
    out << "gap_size = " << m_gapSize << "\n";
    out << "border_width = " << m_borderWidth << "\n";
    out << "border_color = \"" << m_borderColor << "\"\n";
    out << "focused_border_color = \"" << m_focusedBorderColor << "\"\n";
    out << "\n";
    
    // Write [decoration]
    out << "[decoration]\n";
    out << "enabled = " << (m_decorationsEnabled ? "true" : "false") << "\n";
    out << "titlebar_height = " << m_titlebarHeight << "\n";
    out << "bg_color = \"" << m_decorationBgColor << "\"\n";
    out << "text_color = \"" << m_decorationTextColor << "\"\n";
    out << "\n";
    
    // Write [wallpaper]
    out << "[wallpaper]\n";
    if (!m_wallpaperPath.isEmpty()) {
        out << "path = \"" << m_wallpaperPath << "\"\n";
    }
    out << "mode = \"" << m_wallpaperMode << "\"\n";
    out << "\n";
    
    file.close();
    
    qDebug() << "Config saved to:" << path;
    emit saved();
}

// Setters
void ConfigManager::setGapSize(int size) {
    if (m_gapSize != size) {
        m_gapSize = size;
        emit configChanged();
    }
}

void ConfigManager::setBorderWidth(int width) {
    if (m_borderWidth != width) {
        m_borderWidth = width;
        emit configChanged();
    }
}

void ConfigManager::setBorderColor(const QString &color) {
    if (m_borderColor != color) {
        m_borderColor = color;
        emit configChanged();
    }
}

void ConfigManager::setFocusedBorderColor(const QString &color) {
    if (m_focusedBorderColor != color) {
        m_focusedBorderColor = color;
        emit configChanged();
    }
}

void ConfigManager::setDecorationsEnabled(bool enabled) {
    if (m_decorationsEnabled != enabled) {
        m_decorationsEnabled = enabled;
        emit configChanged();
    }
}

void ConfigManager::setTitlebarHeight(int height) {
    if (m_titlebarHeight != height) {
        m_titlebarHeight = height;
        emit configChanged();
    }
}

void ConfigManager::setDecorationBgColor(const QString &color) {
    if (m_decorationBgColor != color) {
        m_decorationBgColor = color;
        emit configChanged();
    }
}

void ConfigManager::setDecorationTextColor(const QString &color) {
    if (m_decorationTextColor != color) {
        m_decorationTextColor = color;
        emit configChanged();
    }
}

void ConfigManager::setWallpaperPath(const QString &path) {
    if (m_wallpaperPath != path) {
        m_wallpaperPath = path;
        emit configChanged();
    }
}

void ConfigManager::setWallpaperMode(const QString &mode) {
    if (m_wallpaperMode != mode) {
        m_wallpaperMode = mode;
        emit configChanged();
    }
}

void ConfigManager::load() {
    loadFromFile();
}

void ConfigManager::save() {
    saveToFile();
}

void ConfigManager::reload() {
    loadFromFile();
}

void ConfigManager::reloadCompositor() {
    if (!m_ipc) {
        emit reloadFailed("Not connected to compositor");
        return;
    }
    
    if (starview_ipc_reload_config(m_ipc)) {
        qDebug() << "Compositor config reloaded successfully";
    } else {
        emit reloadFailed("Failed to reload compositor config");
    }
}
