#include "WallpaperManager.h"
#include <QFileDialog>
#include <QStandardPaths>
#include <QDebug>

WallpaperManager::WallpaperManager(QObject *parent) : QObject(parent) {
}

void WallpaperManager::setWallpaper(const QString &path) {
    if (path.isEmpty()) {
        emit error("Empty wallpaper path");
        return;
    }
    
    // Copy wallpaper to ~/.config/starview/wallpaper
    QString destDir = QDir::homePath() + "/.config/starview";
    QDir dir(destDir);
    if (!dir.exists()) {
        dir.mkpath(".");
    }
    
    QString ext = QFileInfo(path).suffix();
    QString destPath = destDir + "/wallpaper." + ext;
    
    // Remove old wallpaper
    QFile::remove(destPath);
    
    // Copy new wallpaper
    if (!QFile::copy(path, destPath)) {
        emit error("Failed to copy wallpaper");
        return;
    }
    
    m_currentWallpaper = destPath;
    emit wallpaperChanged();
    
    qDebug() << "Wallpaper set to:" << destPath;
    
    // Generate colors with matugen
    generateColors(destPath);
}

void WallpaperManager::generateColors(const QString &wallpaperPath) {
    QProcess *process = new QProcess(this);
    
    connect(process, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
        [this, process](int exitCode, QProcess::ExitStatus status) {
            if (exitCode == 0 && status == QProcess::NormalExit) {
                qDebug() << "Matugen colors generated successfully";
                emit colorsGenerated();
            } else {
                qWarning() << "Matugen failed:" << process->errorString();
                emit error("Failed to generate colors with matugen");
            }
            process->deleteLater();
        });
    
    // Run matugen
    QStringList args = {"image", wallpaperPath, "-j", "json"};
    process->start("matugen", args);
    
    qDebug() << "Running matugen on:" << wallpaperPath;
}

QString WallpaperManager::selectWallpaper() {
    QString picturesPath = QStandardPaths::writableLocation(QStandardPaths::PicturesLocation);
    
    QString path = QFileDialog::getOpenFileName(
        nullptr,
        "Select Wallpaper",
        picturesPath,
        "Images (*.png *.jpg *.jpeg *.webp)"
    );
    
    return path;
}
